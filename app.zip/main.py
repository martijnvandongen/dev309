import logging
import jinja2
import boto3
import random
import string
import os

from aws_lambda_powertools.event_handler import LambdaFunctionUrlResolver, Response, content_types

logger = logging.getLogger()
logger.setLevel(logging.INFO)

j2 = jinja2.Environment(loader=jinja2.FileSystemLoader("templates/"))
app = LambdaFunctionUrlResolver()

dynamodb = boto3.resource('dynamodb')

def generate_token():
    return ''.join(random.choices(string.ascii_letters + string.digits, k=16))

def return_page(page_body):
    return Response(
        status_code=200,
        content_type=content_types.TEXT_HTML,
        body=page_body
    )

def return_redirect(location):
    return Response(
        status_code=302,
        headers={
            "Location": location
        }
    )

# cloudfront has a default object "index.html", because "/" doesn't work...
@app.get("/index.html")
def homepage():
    base = j2.get_template("index.html")
    page = base.render(test="test")
    return return_page(page)

@app.get("/create_new")
def create_new():
    id = generate_token()
    password = generate_token()
    table = dynamodb.Table(os.environ['LISTS_TABLE'])
    table.put_item(
        Item={
            "PK": f"LIST#{id}",
            "SK": f"LIST",
            "password": password
        }
    )
    return return_redirect(f"/{id}/?password={password}")

@app.get("/<list_id>/")
def get_list(list_id):
    base = j2.get_template("public.html")
    password: str = app.current_event.query_string_parameters["password"]
    table = dynamodb.Table(os.environ['LISTS_TABLE'])
    item = table.get_item(Key={'PK': f"LIST#{list_id}", 'SK': f"LIST"})
    page = base.render(data=item, password=password)
    return Response(
        status_code=200,
        content_type=content_types.TEXT_HTML,
        body=page
    )

# anyone is able to cross an item (strike through)
@app.get("/<list_id>/cross/<item_id>")
def capture_update(id):
    return Response(
        status_code=200,
        content_type=content_types.TEXT_HTML,
        body=data
    )

# the owner is able to add an item
@app.post("/<list_id>/add")
def capture_update(id):
    data: dict = app.current_event.json_body
    base = j2.get_template("post.html")
    page = base.render(data)
    return Response(
        status_code=200,
        content_type=content_types.TEXT_HTML,
        body=data
    )

# the owner is allowed to delete items
# items will placed in a 30 day bin
@app.get("/<list_id>/delete/<item_id>")
def capture_update(list_id, item_id):
    return Response(
        status_code=200,
        content_type=content_types.TEXT_HTML,
        body=data
    )

def lambda_handler(event: dict, context) -> dict:
    return app.resolve(event, context)

if __name__ == '__main__':
    print(homepage())