# use mimetypes library to be certain, e.g., mimetypes.types_map[".json"]

APPLICATION_JSON = "application/json"
TEXT_PLAIN = "text/plain"
TEXT_HTML = "text/html"
