"""Exposes version constant to avoid circular dependencies."""

VERSION = "3.0.0"
