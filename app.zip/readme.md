# App

This is a generic app which we will build to it's easy to be used in cdk, cfn and sdk. 

Features:

1. Create a shared list
2. Add items to the list (only via private link)
3. Delete items from the list (only via private link)
4. Cross off items on the list

Use cases:

1. An ad-hoc todo list or shopping list
2. A birthday wishes list to share 
